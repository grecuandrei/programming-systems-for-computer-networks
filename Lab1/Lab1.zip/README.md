How to run:

    python3.9 lab1.py > data.out